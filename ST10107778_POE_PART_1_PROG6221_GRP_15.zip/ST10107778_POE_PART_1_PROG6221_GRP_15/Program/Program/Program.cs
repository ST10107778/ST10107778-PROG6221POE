﻿using System;
using System.Collections.Generic;

class Recipe
{
    // Fields
    private int numIngredients;
    private string[] ingredientNames;
    private double[] ingredientQuantities;
    private string[] ingredientUnits;
    private int numSteps;
    private string[] stepDescriptions;

    public Recipe()
    {
        numIngredients = 0;
        ingredientNames = new string[0];
        ingredientQuantities = new double[0];
        ingredientUnits = new string[0];
        numSteps = 0;
        stepDescriptions = new string[0];
    }

    // Methods
    public void EnterDetails()
    {
        Console.Write("Enter the number of ingredients: ");
        numIngredients = int.Parse(Console.ReadLine());

        ingredientNames = new string[numIngredients];
        ingredientQuantities = new double[numIngredients];
        ingredientUnits = new string[numIngredients];

        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write($"Enter name of ingredient {i + 1}: ");
            ingredientNames[i] = Console.ReadLine();

            Console.Write($"Enter quantity of ingredient {i + 1}: ");
            ingredientQuantities[i] = double.Parse(Console.ReadLine());

            Console.Write($"Enter unit of measurement of ingredient {i + 1}: ");
            ingredientUnits[i] = Console.ReadLine();
        }

        Console.Write("Enter the number of steps: ");
        numSteps = int.Parse(Console.ReadLine());

        stepDescriptions = new string[numSteps];

        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Enter description of step {i + 1}: ");
            stepDescriptions[i] = Console.ReadLine();
        }
    }

    public void Display()
    {
        Console.WriteLine("Recipe:");

        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine($"{ingredientNames[i]}: {ingredientQuantities[i]} {ingredientUnits[i]}");
        }

        Console.WriteLine("Steps:");

        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine($"{i + 1}. {stepDescriptions[i]}");
        }
    }

    public void Scale(double factor)
    {
        for (int i = 0; i < numIngredients; i++)
        {
            ingredientQuantities[i] *= factor;
        }
    }

    public void Reset()
    {
        for (int i = 0; i < numIngredients; i++)
        {
            ingredientQuantities[i] /= 2;
        }
    }

    public void Clear()
    {
        numIngredients = 0;
        ingredientNames = new string[0];
        ingredientQuantities = new double[0];
        ingredientUnits = new string[0];
        numSteps = 0;
        stepDescriptions = new string[0];
    }

}

class Program
{
    static void Main(string[] args)
    {
        Recipe recipe = new Recipe();

        while (true)
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("1. Enter recipe details");
            Console.WriteLine("2. Display recipe");
            Console.WriteLine("3. Scale recipe");
            Console.WriteLine("4. Reset quantities");
            Console.WriteLine("5. Clear all data");
            Console.WriteLine("6. Exit");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    recipe.EnterDetails();
                    break;

                case 2:
                    recipe.Display();
                    break;

                case 3:
                    Console.Write("Enter scale factor: ");
                    double factor = double.Parse(Console.ReadLine());
                    recipe.Scale(factor);
                    break;

                case 4:
                    recipe.Reset();
                    break;

                case 5:
                    recipe.Clear();
                    break;

                case 6:
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }
        }
    }

}